package com.clipper.video;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Build;
import java.io.FileInputStream;
import java.io.OutputStream;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import java.io.File;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 101;
    private Uri selectedVideo;
    private long durationMs = 0;
    private SeekBar startBar, endBar;
    private TextView videoName, startText, endText, status;
    private VideoView preview;
    private Button exportButton;
    private Transformer transformer;

    private int purple = Color.rgb(168, 85, 247);
    private int bg = Color.rgb(16, 11, 24);
    private int panel = Color.rgb(35, 25, 48);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        buildUi();
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(Color.WHITE); t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private android.graphics.drawable.GradientDrawable shape(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 28, 22, 28);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("CLIPPER", 27, true);
        brand.setTextColor(purple); root.addView(brand);
        TextView sub = text("Potong video, buat konten vertikal", 14, false);
        sub.setTextColor(0xFFB9AFC5); root.addView(sub);

        preview = new VideoView(this);
        preview.setBackground(shape(Color.BLACK, 22));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 520);
        vp.topMargin = 22; root.addView(preview, vp);

        videoName = text("Belum ada video dipilih", 15, true);
        videoName.setPadding(0, 18, 0, 12); root.addView(videoName);

        Button choose = button("＋  Pilih video dari galeri");
        root.addView(choose);
        choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("video/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_VIDEO);
        });

        TextView format = text("FORMAT OUTPUT", 13, true);
        format.setTextColor(purple); format.setPadding(0, 24, 0, 8); root.addView(format);
        TextView ratio = text("9:16  •  Vertikal untuk TikTok, Reels & Shorts", 15, true);
        ratio.setPadding(15, 16, 15, 16); ratio.setBackground(shape(panel, 16)); root.addView(ratio);

        TextView trim = text("POTONG VIDEO", 18, true);
        trim.setPadding(0, 24, 0, 8); root.addView(trim);
        startText = text("Mulai: 00:00", 14, false); root.addView(startText);
        startBar = new SeekBar(this); startBar.setMax(1000); root.addView(startBar);
        endText = text("Akhir: --:--", 14, false); root.addView(endText);
        endBar = new SeekBar(this); endBar.setMax(1000); root.addView(endBar);
        startBar.setProgress(0); endBar.setProgress(1000);
        startBar.setOnSeekBarChangeListener(listener(true));
        endBar.setOnSeekBarChangeListener(listener(false));

        exportButton = button("EKSPOR VIDEO");
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, 58);
        ep.topMargin = 24; root.addView(exportButton, ep);
        exportButton.setOnClickListener(v -> exportVideo());

        status = text("Video hasil ekspor akan disimpan di folder Movies/Clipper.", 13, false);
        status.setTextColor(0xFFB9AFC5); status.setPadding(0, 16, 0, 8); root.addView(status);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(15);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(shape(purple, 18));
        return b;
    }

    private SeekBar.OnSeekBarChangeListener listener(boolean isStart) {
        return new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { updateTimes(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        };
    }

    private void updateTimes() {
        if (durationMs <= 0) return;
        long start = durationMs * startBar.getProgress() / 1000;
        long end = durationMs * endBar.getProgress() / 1000;
        startText.setText("Mulai: " + time(start));
        endText.setText("Akhir: " + time(end));
    }

    private String time(long ms) {
        long sec = ms / 1000;
        return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedVideo = data.getData();
            try { getContentResolver().takePersistableUriPermission(selectedVideo,
                Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            videoName.setText(getName(selectedVideo));
            preview.setVideoURI(selectedVideo);
            preview.setOnPreparedListener(mp -> {
                durationMs = mp.getDuration();
                endBar.setProgress(1000); startBar.setProgress(0); updateTimes();
                preview.start();
            });
            status.setText("Video siap dipotong. Atur titik mulai dan akhir.");
        }
    }

    private String getName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {}
        return "Video terpilih";
    }

    private void exportVideo() {
        if (selectedVideo == null || durationMs <= 0) {
            status.setText("Pilih video terlebih dahulu."); return;
        }
        long start = durationMs * startBar.getProgress() / 1000;
        long end = durationMs * endBar.getProgress() / 1000;
        if (end <= start + 500) {
            status.setText("Durasi potongan minimal 1 detik."); return;
        }
        exportButton.setEnabled(false);
        status.setText("Sedang mengekspor video… jangan tutup aplikasi.");
        File folder = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "Clipper");
        if (!folder.exists()) folder.mkdirs();
        String output = new File(folder, "Clipper_" + System.currentTimeMillis() + ".mp4").getAbsolutePath();

        MediaItem mediaItem = new MediaItem.Builder().setUri(selectedVideo)
            .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(start).setEndPositionMs(end).build()).build();
        EditedMediaItem edited = new EditedMediaItem.Builder(mediaItem).build();
        transformer = new Transformer.Builder(this).addListener(new Transformer.Listener() {
            @Override public void onCompleted(Composition composition, ExportResult result) {
                runOnUiThread(() -> {
                    exportButton.setEnabled(true);
                    String savedLocation = publishToGallery(output);
                    status.setText("Selesai! Video tersimpan di: " + savedLocation);
                    Toast.makeText(MainActivity.this, "Video berhasil disimpan ke galeri", Toast.LENGTH_LONG).show();
                });
            }
            @Override public void onError(Composition composition, ExportResult result, ExportException exception) {
                runOnUiThread(() -> {
                    exportButton.setEnabled(true);
                    status.setText("Ekspor gagal: " + exception.getMessage());
                });
            }
        }).build();
        transformer.start(edited, output);
    }

    private String publishToGallery(String sourcePath) {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, new File(sourcePath).getName());
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Clipper");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri destination = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (destination == null) return sourcePath;
            try (FileInputStream input = new FileInputStream(sourcePath);
                 OutputStream output = getContentResolver().openOutputStream(destination)) {
                if (output == null) throw new IllegalStateException("Tidak bisa membuka penyimpanan galeri");
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                output.flush();
                ContentValues ready = new ContentValues();
                ready.put(MediaStore.Video.Media.IS_PENDING, 0);
                getContentResolver().update(destination, ready, null, null);
                new File(sourcePath).delete();
                return "Galeri > Movies/Clipper";
            } catch (Exception e) {
                getContentResolver().delete(destination, null, null);
                return sourcePath;
            }
        }
        return sourcePath;
    }

    @Override protected void onStop() {
        super.onStop();
        if (transformer != null) {
            try { transformer.cancel(); } catch (Exception ignored) {}
        }
    }
}
