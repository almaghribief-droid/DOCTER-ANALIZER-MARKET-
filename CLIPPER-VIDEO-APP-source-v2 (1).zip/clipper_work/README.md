# Clipper Video App

Proyek Android awal untuk memilih video, melihat preview, mengatur titik mulai/akhir, lalu mengekspor potongan MP4.

## Build APK lewat GitHub Actions (bisa dari HP)
1. Upload seluruh isi folder proyek ini ke repository GitHub (bukan file ZIP-nya).
2. Buka tab **Actions** dan aktifkan Actions bila diminta.
3. Jalankan workflow **Build Clipper APK** atau push ke branch `main`/`master`.
4. Setelah workflow sukses, buka hasil run → **Artifacts** → unduh `Clipper-debug-apk`.
5. Ekstrak artifact dan instal `app-debug.apk`.

## Status dan batasan versi ini
- APK debug untuk pengujian.
- Bisa memilih video, preview, mengatur titik mulai/akhir, dan mengekspor potongan MP4.
- Android 10+ akan menyalin hasil ekspor ke Galeri pada folder Movies/Clipper.
- Versi ini belum menerapkan crop/konversi rasio 9:16 pada file video, dan belum memiliki pilihan resolusi 720p/1080p.
- Build belum diverifikasi di lingkungan ini; workflow GitHub Actions disediakan untuk membangunnya.
